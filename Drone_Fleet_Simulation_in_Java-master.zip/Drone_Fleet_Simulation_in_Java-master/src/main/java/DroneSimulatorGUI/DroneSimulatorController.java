package DroneSimulatorGUI;

import DroneSimulator.*;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.Component;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

public class DroneSimulatorController {

    @FXML private Canvas canvas;

    @FXML private TextField droneCountField;
    @FXML private Button applyDroneCountBtn;

    @FXML private Button initDronesRandomBtn;
    @FXML private Button initDronesZeroBtn;

    @FXML private Button randomTargetBtn;
    @FXML private Button randomTargetsPerDroneBtn;

    @FXML private Button loadConstantsBtn;

    // Shared target input
    @FXML private TextField targetXField;
    @FXML private TextField targetYField;
    @FXML private TextField targetZField;
    @FXML private Button setTargetBtn;

    // NEW: simulation time input
    @FXML private TextField totalTimeField;
    @FXML private Button applyTimeBtn;

    // NEW: per-drone target input
    @FXML private TextField droneIdField;
    @FXML private TextField droneTargetXField;
    @FXML private TextField droneTargetYField;
    @FXML private TextField droneTargetZField;
    @FXML private Button setDroneTargetBtn;

    @FXML private Button startBtn;
    @FXML private Button pauseBtn;
    @FXML private Button resetBtn;

    @FXML private Slider speedSlider;

    @FXML private Label targetLabel;
    @FXML private Label statusLabel;

    private double dt = 0.01;
    private double totalTime = 60.0;
    private int numDrones = 4;

    private double mass = 1.5;
    private double kd = 0.2;

    private double Ix = 0.02, Iy = 0.02, Iz = 0.04;

    private double kp = 3.5;
    private double kdCtrl = 2.5;
    private double kR = 8.5;
    private double kOmega = 0.15;

    private double formKp = 0.0;
    private double formKv = 0.0;
    private double kRep = 1.0;

    private double commRange = 50.0;
    private double packetLoss = 0.01;

    private double envWidth = 100.0;
    private double envHeight = 100.0;
    private double envDepth = 1000.0;

    private double minSafeDistance = 1.0;

    private String positionsCsv = "Positions.csv";
    private String metricsTxt = "Metrics.txt";

    private final Random rand = new Random();

    private List<Drone> drones = new ArrayList<>();
    private Simulator simulator;
    private Logger logger;

    private boolean running = false;
    private boolean finished = false;

    private double simTime = 0.0;
    private long lastNs = 0;
    private double accumulator = 0;

    private AnimationTimer timer;

    private boolean metricsWritten = false;

    private Vector3 mainTarget = null;
    private double formationRadius = 0.0;

    private boolean perDroneTargetsMode = false;

    private static final double PAD = 40;
    private static final double DRONE_R = 6;

    @FXML
    public void initialize() {
        if (speedSlider != null) {
            speedSlider.setMin(0.2);
            speedSlider.setMax(5.0);
            speedSlider.setValue(1.0);
            speedSlider.setShowTickLabels(true);
            speedSlider.setShowTickMarks(true);
        }

        // show current total time in field
        if (totalTimeField != null) totalTimeField.setText(String.valueOf(totalTime));

        updateTargetLabel();
        statusLabel.setText("Ready. Initialize drones, set targets, Start. (You can load constants file too.)");

        rebuildSimulator(); // safe even if drones empty
        setupLoop();
        draw();
    }

    @FXML
    public void loadConstantsFromFile() {
        SwingUtilities.invokeLater(() -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select simulation.properties");
            chooser.setFileFilter(new FileNameExtensionFilter("Properties (*.properties)", "properties"));

            int result = chooser.showOpenDialog((Component) null);
            if (result != JFileChooser.APPROVE_OPTION) {
                javafx.application.Platform.runLater(() -> statusLabel.setText("Load cancelled."));
                return;
            }

            File file = chooser.getSelectedFile();
            try {
                loadProperties(file);

                javafx.application.Platform.runLater(() -> {
                    statusLabel.setText("Loaded constants: " + file.getName());

                    if (droneCountField != null) droneCountField.setText(String.valueOf(numDrones));
                    if (totalTimeField != null) totalTimeField.setText(String.valueOf(totalTime));

                    resetAllStateHard();
                    rebuildSimulator();
                    updateTargetLabel();
                    draw();
                });

            } catch (Exception ex) {
                javafx.application.Platform.runLater(() ->
                        statusLabel.setText("Failed to load constants: " + ex.getMessage()));
                ex.printStackTrace();
            }
        });
    }

    private void loadProperties(File file) throws IOException {
        Properties p = new Properties();
        try (FileInputStream fis = new FileInputStream(file)) {
            p.load(fis);
        }

        dt = getDouble(p, "dt", dt);
        totalTime = getDouble(p, "totalTime", totalTime);
        numDrones = getInt(p, "numDrones", numDrones);

        mass = getDouble(p, "mass", mass);
        kd = getDouble(p, "kd", kd);

        Ix = getDouble(p, "Ix", Ix);
        Iy = getDouble(p, "Iy", Iy);
        Iz = getDouble(p, "Iz", Iz);

        kp = getDouble(p, "kp", kp);
        kdCtrl = getDouble(p, "kdCtrl", kdCtrl);
        kR = getDouble(p, "kR", kR);
        kOmega = getDouble(p, "kOmega", kOmega);

        formKp = getDouble(p, "formKp", formKp);
        formKv = getDouble(p, "formKv", formKv);
        kRep = getDouble(p, "kRep", kRep);
        minSafeDistance = getDouble(p, "minSafeDistance", minSafeDistance);

        commRange = getDouble(p, "commRange", commRange);
        packetLoss = getDouble(p, "packetLoss", packetLoss);

        envWidth = getDouble(p, "envWidth", envWidth);
        envHeight = getDouble(p, "envHeight", envHeight);
        envDepth = getDouble(p, "envDepth", envDepth);

        positionsCsv = p.getProperty("positionsCsv", positionsCsv);
        metricsTxt = p.getProperty("metricsTxt", metricsTxt);
    }

    private static double getDouble(Properties p, String key, double fallback) {
        String v = p.getProperty(key);
        if (v == null) return fallback;
        return Double.parseDouble(v.trim());
    }

    private static int getInt(Properties p, String key, int fallback) {
        String v = p.getProperty(key);
        if (v == null) return fallback;
        return Integer.parseInt(v.trim());
    }

    @FXML
    public void applyTotalTime() {
        try {
            double t = Double.parseDouble(totalTimeField.getText().trim());
            if (t <= 0) {
                statusLabel.setText("Total time must be > 0.");
                return;
            }
            totalTime = t;
            statusLabel.setText("Total time set to " + totalTime + " seconds.");
        } catch (Exception e) {
            statusLabel.setText("Invalid total time input.");
        }
    }

    @FXML
    public void applyDroneCount() {
        int n = safeParseInt(droneCountField.getText(), numDrones);
        if (n < 1) n = 1;
        if (n > 200) n = 200;
        numDrones = n;

        drones.clear();
        mainTarget = null;
        formationRadius = 0.0;
        perDroneTargetsMode = false;

        running = false;
        finished = false;
        simTime = 0;
        accumulator = 0;
        lastNs = 0;
        metricsWritten = false;

        rebuildSimulator();
        updateTargetLabel();
        statusLabel.setText("Drone count set to " + numDrones + ". Now initialize drones.");
        draw();
    }

    @FXML
    public void initDronesRandom() {
        initDrones(false);
        statusLabel.setText("Drones initialized randomly. Now set target.");
        draw();
    }

    @FXML
    public void initDronesZero() {
        initDrones(true);
        statusLabel.setText("Drones initialized at (0,0,0). Now set target.");
        draw();
    }

    @FXML
    public void randomizeTarget() {
        if (drones.isEmpty()) {
            statusLabel.setText("Initialize drones first.");
            return;
        }

        double x = rand.nextDouble() * 80 + 10;
        double y = rand.nextDouble() * 80 + 10;
        double z = Math.min(envDepth, rand.nextDouble() * 30 + 5);

        setMainTarget(new Vector3(x, y, z));
        statusLabel.setText("Random shared target set. Press Start.");
        draw();
    }

    @FXML
    public void randomizeTargetsPerDrone() {
        if (drones.isEmpty()) {
            statusLabel.setText("Initialize drones first.");
            return;
        }

        perDroneTargetsMode = true;
        mainTarget = null;
        formationRadius = 0.0;
        metricsWritten = false;

        for (int i = 0; i < drones.size(); i++) {
            double tx = rand.nextDouble() * 80 + 10;
            double ty = rand.nextDouble() * 80 + 10;
            double tz = Math.min(envDepth, rand.nextDouble() * 30 + 5);

            drones.get(i).setRtar(new Vector3(tx, ty, tz));
            drones.get(i).setVtar(Vector3.zero());
        }

        updateTargetLabel();
        statusLabel.setText("Random targets assigned per drone. Press Start.");
        draw();
    }

    @FXML
    public void setTarget() {
        if (drones.isEmpty()) {
            statusLabel.setText("Initialize drones first.");
            return;
        }

        try {
            double x = clamp(Double.parseDouble(targetXField.getText()), 0, envWidth);
            double y = clamp(Double.parseDouble(targetYField.getText()), 0, envHeight);
            double z = clamp(Double.parseDouble(targetZField.getText()), 0, envDepth);

            setMainTarget(new Vector3(x, y, z));
            statusLabel.setText("Shared target set. Press Start.");
            draw();
        } catch (Exception ex) {
            statusLabel.setText("Invalid target input.");
        }
    }

    @FXML
    public void setTargetForDrone() {
        if (drones.isEmpty()) {
            statusLabel.setText("Initialize drones first.");
            return;
        }

        try {
            int id = Integer.parseInt(droneIdField.getText().trim());
            if (id < 0 || id >= drones.size()) {
                statusLabel.setText("Drone ID must be between 0 and " + (drones.size() - 1));
                return;
            }

            double x = clamp(Double.parseDouble(droneTargetXField.getText()), 0, envWidth);
            double y = clamp(Double.parseDouble(droneTargetYField.getText()), 0, envHeight);
            double z = clamp(Double.parseDouble(droneTargetZField.getText()), 0, envDepth);

            perDroneTargetsMode = true;   // switch to per-drone mode
            mainTarget = null;
            formationRadius = 0.0;
            metricsWritten = false;

            drones.get(id).setRtar(new Vector3(x, y, z));
            drones.get(id).setVtar(Vector3.zero());

            updateTargetLabel();
            statusLabel.setText("Target set for Drone " + id + " to (" + x + "," + y + "," + z + ")");
            draw();

        } catch (Exception e) {
            statusLabel.setText("Invalid per-drone target input.");
        }
    }

    @FXML
    public void startSimulation() {
        if (drones.isEmpty()) {
            statusLabel.setText("Initialize drones first.");
            return;
        }

        if (!perDroneTargetsMode && mainTarget == null) {
            statusLabel.setText("Set shared target OR use per-drone targets first.");
            return;
        }

        running = true;
        statusLabel.setText("Running...");
    }

    @FXML
    public void pauseSimulation() {
        running = false;
        statusLabel.setText("Paused");
    }

    @FXML
    public void resetSimulation() {
        running = false;
        finished = false;
        simTime = 0.0;
        accumulator = 0;
        lastNs = 0;
        metricsWritten = false;

        if (simulator != null) simulator.reset();

        statusLabel.setText("Reset done.");
        draw();
    }

    private void resetAllStateHard() {
        running = false;
        finished = false;
        simTime = 0;
        accumulator = 0;
        lastNs = 0;
        metricsWritten = false;

        drones.clear();
        mainTarget = null;
        formationRadius = 0;
        perDroneTargetsMode = false;
    }

    private void initDrones(boolean zeroStart) {
        finished = false;
        running = false;
        simTime = 0;
        accumulator = 0;
        lastNs = 0;
        metricsWritten = false;

        drones = new ArrayList<>();

        Vector3 inertia = new Vector3(Ix, Iy, Iz);
        Vector3 initialVelocity = Vector3.zero();
        Matrix3D initialRotation = Matrix3D.identity();

        Vector3 dummyTarget = new Vector3(0, 0, 0);
        Vector3 targetVelocity = Vector3.zero();

        for (int i = 0; i < numDrones; i++) {
            Vector3 initialPosition = zeroStart
                    ? new Vector3(0, 0, 0)
                    : new Vector3(rand.nextDouble() * 20, rand.nextDouble() * 20, 1.0);

            drones.add(new Drone(
                    i,
                    mass,
                    inertia,
                    kd,
                    initialPosition,
                    dummyTarget,
                    targetVelocity,
                    initialVelocity,
                    initialRotation
            ));
        }

        mainTarget = null;
        formationRadius = 0.0;
        perDroneTargetsMode = false;

        rebuildSimulator();
        updateTargetLabel();
    }

    private void setMainTarget(Vector3 t) {
        perDroneTargetsMode = false;
        this.mainTarget = t;
        metricsWritten = false;

        double minDist = minSafeDistance * 1.25;
        formationRadius = Math.max(2.0, (drones.size() * minDist) / (2.0 * Math.PI));

        applyCircleSlotTargets();
        updateTargetLabel();
    }

    private void applyCircleSlotTargets() {
        if (mainTarget == null || drones.isEmpty()) return;

        double z = clamp(mainTarget.z, 0, envDepth);

        for (int i = 0; i < drones.size(); i++) {
            double ang = (2.0 * Math.PI * i) / drones.size();
            double dx = formationRadius * Math.cos(ang);
            double dy = formationRadius * Math.sin(ang);

            double tx = clamp(mainTarget.x + dx, 0, envWidth);
            double ty = clamp(mainTarget.y + dy, 0, envHeight);

            drones.get(i).setRtar(new Vector3(tx, ty, z));
            drones.get(i).setVtar(Vector3.zero());
        }
    }

    private void rebuildSimulator() {
        Controller controller = new Controller(kp, kdCtrl, kR, kOmega, mass);
        controller.setDesiredRotation(Matrix3D.identity());
        controller.setDesiredAngularVelocity(Vector3.zero());

        FormationManager formationManager = new FormationManager(formKp, formKv);
        CollisionAvoidance collisionAvoidance = new CollisionAvoidance(kRep, minSafeDistance);
        CommunicationModule communicationModule = new CommunicationModule(commRange, packetLoss);

        Environment environment = new Environment(envWidth, envHeight, envDepth);

        logger = new Logger(positionsCsv, metricsTxt, minSafeDistance);
        communicationModule.setLogger(logger);

        simulator = new Simulator(
                drones,
                controller,
                formationManager,
                collisionAvoidance,
                communicationModule,
                environment,
                logger,
                dt
        );
    }

    private void setupLoop() {
        timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (lastNs == 0) {
                    lastNs = now;
                    return;
                }
                double frameDt = (now - lastNs) / 1_000_000_000.0;
                lastNs = now;

                double speed = (speedSlider != null) ? speedSlider.getValue() : 1.0;

                if (running && !finished && simulator != null) {
                    accumulator += frameDt * speed;

                    while (accumulator >= dt && !finished) {
                        stepSimulationOnce();
                        accumulator -= dt;
                        simTime += dt;

                        if (simTime >= totalTime) {
                            finished = true;
                            running = false;

                            if (!metricsWritten && logger != null) {
                                try {
                                    logger.finalize(drones);
                                    metricsWritten = true;
                                } catch (Exception e) {
                                    statusLabel.setText("Finished but metrics write failed: " + e.getMessage());
                                    e.printStackTrace();
                                }
                            }

                            statusLabel.setText("Finished (t=" + String.format("%.2f", simTime) + "s) | Metrics saved");
                        }
                    }
                }

                draw();

                if (!finished && running) {
                    statusLabel.setText(String.format(
                            "t = %.2f / %.2f | drones=%d | speed=%.2fx",
                            simTime, totalTime, drones.size(), speed
                    ));
                }
            }
        };
        timer.start();
    }

    private void stepSimulationOnce() {
        try {
            simulator.step();
        } catch (Exception ex) {
            running = false;
            statusLabel.setText("Simulation error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    private void draw() {
        GraphicsContext g = canvas.getGraphicsContext2D();
        double w = canvas.getWidth();
        double h = canvas.getHeight();

        g.setFill(Color.web("#f2f2f2"));
        g.fillRect(0, 0, w, h);

        double scaleX = (w - 2 * PAD) / envWidth;
        double scaleY = (h - 2 * PAD) / envHeight;
        double scale = Math.min(scaleX, scaleY);

        double boxW = envWidth * scale;
        double boxH = envHeight * scale;
        double x0 = (w - boxW) / 2.0;
        double y0 = (h - boxH) / 2.0;

        g.setStroke(Color.GRAY);
       // g.setStroke(Color.RED);
        g.setLineWidth(2.0);
        g.strokeRect(x0, y0, boxW, boxH);

        g.setFill(Color.GRAY);
        g.setFont(Font.font("Arial", 14));
        g.fillText("Environment (X:0.." + (int) envWidth + ", Y:0.." + (int) envHeight + ")", x0 + 8, y0 - 8);

        // shared mode target
        if (!perDroneTargetsMode && mainTarget != null) {
            double tx = x0 + mainTarget.x * scale;
            double ty = y0 + (envHeight - mainTarget.y) * scale;

            double rr = formationRadius * scale;
            g.setStroke(Color.rgb(255, 0, 0, 0.20));
            g.setLineWidth(3.0);
            g.strokeOval(tx - rr, ty - rr, rr * 2, rr * 2);

            g.setFill(Color.RED);
            g.fillOval(tx - 6, ty - 6, 12, 12);

            g.setFont(Font.font("Arial", 14));
            g.fillText("Target", tx + 10, ty - 10);
        }

        // per-drone mode targets
        if (perDroneTargetsMode) {
            g.setFill(Color.rgb(255, 0, 0, 0.25)); // light red markers
            for (Drone d : drones) {
                Vector3 t = d.getRtar();
                double tx = x0 + t.x * scale;
                double ty = y0 + (envHeight - t.y) * scale;
                g.fillOval(tx - 4, ty - 4, 8, 8);
            }
        }

        drones.stream()
                .sorted(Comparator.comparingInt(Drone::getId))
                .forEach(d -> drawDrone2D(g, d, x0, y0, scale));
    }

    private void drawDrone2D(GraphicsContext g, Drone d, double x0, double y0, double scale) {
        Vector3 p = d.getPosition();

        double sx = x0 + p.x * scale;
        double sy = y0 + (envHeight - p.y) * scale;

        g.setFill(Color.BLACK);
        //g.fillOval(sx - DRONE_R, sy - DRONE_R, DRONE_R * 2, DRONE_R * 2);

        g.fillRect(sx -10 / 2.0, sy - 10 / 2.0, 10, 10);
        g.setFill(Color.BLACK);
        g.setFont(Font.font("Arial", 12));
        g.fillText("D" + d.getId() + " z=" + String.format("%.1f", p.z), sx + 8, sy);
    }

    private void updateTargetLabel() {
        if (targetLabel == null) return;

        if (perDroneTargetsMode) {
            targetLabel.setText("Targets: per-drone mode");
            return;
        }

        if (mainTarget == null) {
            targetLabel.setText("Target: (not set)");
        } else {
            targetLabel.setText(String.format("Target: (%.2f, %.2f, %.2f)",
                    mainTarget.x, mainTarget.y, mainTarget.z));
        }
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static int safeParseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); }
        catch (Exception e) { return fallback; }
    }
}
