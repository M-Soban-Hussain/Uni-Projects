package DroneSimulatorGUI;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));

        // Load UI
        Scene scene = new Scene(fxmlLoader.load());

        // Make window big enough for canvas + controls
        stage.setTitle("Drone Fleet Simulator");
        stage.setScene(scene);

        stage.setWidth(1150);
        stage.setHeight(720);

        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
