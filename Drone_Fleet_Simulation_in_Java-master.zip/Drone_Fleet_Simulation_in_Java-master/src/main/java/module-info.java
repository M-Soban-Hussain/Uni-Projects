module DroneSimulatorGUI {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;

    opens DroneSimulatorGUI to javafx.fxml;
    exports DroneSimulatorGUI;
}
